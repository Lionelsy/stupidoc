import React, { Component } from "react";
import AppNavbar from "./appNavbar";
import AppSidebar from "./appSidebar";
import DocCard from "./docCard";
import { Layout, Row, Col } from "antd";
import UpLoad from "./upLoadButton";
import NewBotton from "./newBotton";
const { Header, Footer, Sider, Content } = Layout;

class App extends Component {
  state = {
    id: 1,
    isLoading: true,
    documents: [],
    appNavbarWidth: "100%",
    appNavbarHeight: "10%",
    appSidebarWidth: "100%",
    appSidebarHeight: "90vh",
    appButtonWidth: "150px"
  };

  async componentDidMount() {
    const response = await fetch(`/api/${this.state.id}`);
    const body = await response.json();
    this.setState({ isLoading: false, documents: body });
  }

  render() {
    return (
      <div>
        <AppNavbar
          width={this.state.appNavbarWidth}
          height={this.state.appNavbarHeight}
        />
        <Row>
          <Col span={3}>
            <AppSidebar
              width={this.state.appSidebarWidth}
              height={this.state.appSidebarHeight}
              documents={this.state.documents}
            />
          </Col>
          <Col span={18}>
            <DocCard />
          </Col>
          <div style={{ textAlign: "center" }}>
            <Col span={3}>
              <UpLoad width={this.state.appButtonWidth} />
              <NewBotton width={this.state.appButtonWidth} />
            </Col>
          </div>
        </Row>
      </div>
    );
  }
}

export default App;
